# connect4
Startcode project 1TIN 2023
