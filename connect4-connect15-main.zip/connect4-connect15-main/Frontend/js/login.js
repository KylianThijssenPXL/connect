'use strict';

const email = sessionStorage.getItem("email");
const form = document.getElementById("forum");
const error = document.getElementById("errorMessage");
const url = "https://localhost:5001/api/Authentication/token";


if (email != null){
    document.getElementById("mail").value = email
}

form.addEventListener('submit', function (e){
    e.preventDefault();
    var email = document.getElementById("mail").value;
    var password = document.getElementById("password").value;
    if (inputControl() === true){
        fetch(url, {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json;'
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        })
            .then(function (response) {
                if (response.status === 200) {
                    return response.json();
                } else {
                    errorMessage("email or password is wrong");
                    return response.json();
                }
            })
            .then(function (data) {
                if (data && data.token && data.user && data.user.nickName) {
                    sessionStorage.setItem("token", data.token)
                    window.location.href = "waitingroom.html";
                } else {
                    errorMessage(data.message);
                }
            });
    }
})

function errorMessage(msg){
    error.textContent = msg;
    error.style.color = "red";
}

function inputControl(){
    var email = document.getElementById("mail").value;
    var password = document.getElementById("password").value;
    if (email === "" || password === ""){
        errorMessage("Not all fields are filled in");
        return false;
    } else {
        return true
    }
}
