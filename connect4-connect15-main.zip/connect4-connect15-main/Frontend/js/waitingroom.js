'use strict';

const error = document.getElementById("errorMessage");
const loaderDiv = document.getElementById("loaderDiv");
const loadingTextDiv = document.getElementById("loadingTextDiv");
const joinUrl = "https://localhost:5001/api/WaitingPool/join";
const leaveUrl = "https://localhost:5001/api/WaitingPool/leave";
const getUrl = "https://localhost:5001/api/WaitingPool/candidates/me";
const singleUrl = "https://localhost:5001/api/Games/single-player";
let intervalId;

const joinBtn = document.getElementById("joinButton");
joinBtn.addEventListener("click", function () {
    addPlayer();
});

function addPlayer() {
    var gridStyle = document.getElementById("grid").value;
    var gridRows = gridStyle.substring(0, 1);
    var gridColumns = gridStyle.substring(2);
    var automatch = document.getElementById("automatch").checked;
    var popout = document.getElementById("popout").checked;
    var popoutCount = document.getElementById("popOutCount").value;
    var anvil = document.getElementById("anvil").checked;
    var anvilCount = document.getElementById("anvilCount").value;
    var bomb = document.getElementById("bomb").checked;
    var bombCount = document.getElementById("bombCount").value;
    var wall = document.getElementById("wall").checked;
    var wallCount = document.getElementById("wallCount").value;
    var connectSize = document.getElementById("connectSize").value;

    if (!checkConstraints(connectSize, gridRows, gridColumns)) {
        errorMessage("Can not combine this gridsize with the connection size.")
        return;
    }

    fetch(joinUrl, {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json;',
            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
        },
        body: JSON.stringify({
            autoMatchCandidates: automatch,
            enablePopOut: popout,
            popOutCount: popoutCount,
            enableAnvil: anvil,
            anvilCount: anvilCount,
            enableBomb: bomb,
            bombCount: bombCount,
            enableWall: wall,
            wallCount: wallCount,
            connectionSize: connectSize,
            gridRows: gridRows,
            gridColumns: gridColumns
        })
    }).then(function (response) {
        if (response.status === 200) {
            intervalId = setInterval(lookForGame, 1000);

            if (loaderDiv.children.length === 0) {
                let loadingText = document.createElement("label")
                loadingText.textContent = "Looking for players...";
                loadingText.className = "loadingText";
                loadingTextDiv.appendChild(loadingText);

                let loader = document.createElement("span")
                loader.className = "loader";
                loaderDiv.appendChild(loader);
            }
        } else {
            errorMessage(response.message);
            return response.json();
        }
    })
}

const leaveBtn = document.getElementById("leaveButton");
leaveBtn.addEventListener("click", function () {
    removePlayer();
});

function removePlayer() {
    fetch(leaveUrl, {
        method: "POST",
        headers: {
            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
        }
    }).then(function (response) {
        if (response.status === 200) {
            loaderDiv.innerHTML = "";
            loadingTextDiv.innerHTML = "";
            clearInterval(intervalId);
        } else {
            errorMessage(response.message);
            return response.json();
        }
    })
}

function errorMessage(msg) {
    error.textContent = msg;
    error.style.color = "red";
}

function lookForGame() {
    fetch(getUrl, {
        method: "GET",
        headers: {
            'Accept': 'text/plain',
            'Content-Type': 'text/plain',
            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
        }
    }).then(function (response) {
        if (response.status === 200) {
            return response.json();
        }
    }).then(function (data) {
        if (data && data.gameId) {
            if (data.gameId !== "00000000-0000-0000-0000-000000000000") {
                sessionStorage.setItem("gameId", data.gameId)
                window.location.href = "game.html"
            }
        }
    })
}

const singleBtn = document.getElementById("singlePlayer");
singleBtn.addEventListener("click", function () {
    startSinglePlayer();
});

function startSinglePlayer() {
    var gridStyle = document.getElementById("grid").value;
    var gridRows = gridStyle.substring(0, 1);
    var gridColumns = gridStyle.substring(2);
    var automatch = document.getElementById("automatch").checked;
    var popout = document.getElementById("popout").checked;
    var popoutCount = document.getElementById("popOutCount").value;
    var anvil = document.getElementById("anvil").checked;
    var anvilCount = document.getElementById("anvilCount").value;
    var bomb = document.getElementById("bomb").checked;
    var bombCount = document.getElementById("bombCount").value;
    var wall = document.getElementById("wall").checked;
    var wallCount = document.getElementById("wallCount").value;
    var connectSize = document.getElementById("connectSize").value;

    if (!checkConstraints(connectSize, gridRows, gridColumns)) {
        errorMessage("Can not combine this gridsize with the connection size.")
        return;
    }

    fetch(singleUrl, {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json;',
            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
        },
        body: JSON.stringify({
            autoMatchCandidates: automatch,
            enablePopOut: popout,
            popOutCount: popoutCount,
            enableAnvil: anvil,
            anvilCount: anvilCount,
            enableBomb: bomb,
            bombCount: bombCount,
            enableWall: wall,
            wallCount: wallCount,
            connectionSize: connectSize,
            gridRows: gridRows,
            gridColumns: gridColumns
        })
    }).then(function (response) {
        if (response.status === 201) {
            return response.json();
        } else {
            errorMessage(response.message);
        }
    }).then(function (data) {
        if (data && data.id) {
            if (data.id !== "00000000-0000-0000-0000-000000000000") {
                sessionStorage.setItem("gameId", data.id)
                sessionStorage.setItem("singlePlayer", "true")
                window.location.href = "game.html"
            }
        }
    })
}

function checkConstraints(connectSize, rows, columns) {
    return !(connectSize > rows || connectSize > columns);

}