'use strict';

const url = "https://localhost:5001/api/Authentication/register";
var error = document.getElementById("errorMessage");
const form = document.getElementById("forum");


form.addEventListener('submit', function (e) {
    e.preventDefault();
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var email = document.getElementById("email").value;
    sessionStorage.setItem("email", email);
    if (inputControl() === true){
        fetch(url, {
            method: "POST",
            body: JSON.stringify({
                email: email,
                password: password,
                nickName: username,
            }),
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json;'
            }
        })
            .then(function (response){
                if (response.status === 200){
                    window.location.href = "index.html";
                } else {
                    return response.json();
                }
            })
            .then((data) => {
                errorMessage(data.message);
            })
    }
})

function errorMessage(msg){
    error.textContent = msg;
    error.style.color = "red";
}

function inputControl(){
    var email = document.getElementById("email").value;
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var passwordVertification = document.getElementById("passwordverification").value;
    if (email === "" || username === "" || password === ""  || passwordVertification === "" ){
        errorMessage("Not all fields are filled in");
        return false;
    } else {
        return matchPassword();
    }
}


function matchPassword() {
    var pw1 = document.getElementById("password").value;
    var pw2 = document.getElementById("passwordverification").value;
    if (pw1 !== pw2) {
        errorMessage("Password did not match");
        return false;
    } else if (pw1.length < 6 || pw2.length < 6){
        errorMessage("Password must be at least 6 characters long")
        return false;
    } else {
        return true;
    }
}
