'use strict';
const gId = sessionStorage.getItem("gameId");
const url = "https://localhost:5001/api/Games/" + gId;
const output = document.getElementById("div_output");
const disc_output = document.getElementById("disc_table");
const error = document.getElementById("error-message");
const playerToPlayText = document.getElementById("turn-player");
const player1Name = document.getElementById("player1-name");
const player2Name = document.getElementById("player2-name");
let finishedBoolean = false;
let cells = [];
let intervalId;

fetch(url, {
    method: "GET",
    headers: {
        'Accept': 'text/plain',
        'Content-Type': 'text/plain',
        'Authorization': 'Bearer ' + sessionStorage.getItem("token")
    }
})
    .then((response) => {
        if (response.status === 200) {
            return response.json();
        } else {
            throw `error with status ${response.status}`;
        }
    })
    // data wordt in tabel gezet
    .then(async (response) => {
        disc_output.appendChild(discTable(response.grid.numberOfColumns))
        let table = makeTable(response.grid.numberOfRows, response.grid.numberOfColumns);
        output.appendChild(table);
        let base_selector = ".dot_";
        for (let i = 0; i < response.grid.numberOfColumns; i++) {
            let extra_selector = i.toString();
            const disc = document.querySelector(base_selector + extra_selector);
            disc.addEventListener('click', function () {
                makeMove(disc.className.split("_")[1])
            })
        }

        const gameInformation = await getGameInformation();
        if (gameInformation.popOutAllowed === true) {
            const container = document.querySelector('.popoutDiv');
            const label = document.createElement('label');
            label.setAttribute('for', 'popoutToggle');
            label.textContent = 'Use popout?';
            const checkbox = document.createElement('input');
            checkbox.setAttribute('type', 'checkbox');
            checkbox.setAttribute('id', 'popoutToggle');
            container.appendChild(label);
            container.appendChild(checkbox);
        }
        if (gameInformation.anvilAllowed === true) {
            const container = document.querySelector('.anvilDiv');
            const label = document.createElement('label');
            label.setAttribute('for', 'anvilToggle');
            label.textContent = 'Use anvil?';
            const checkbox = document.createElement('input');
            checkbox.setAttribute('type', 'checkbox');
            checkbox.setAttribute('id', 'anvilToggle');
            container.appendChild(label);
            container.appendChild(checkbox);
        }
        if (gameInformation.bombAllowed === true) {
            const container = document.querySelector('.bombDiv');
            const label = document.createElement('label');
            label.setAttribute('for', 'bombToggle');
            label.textContent = 'Use bomb?';
            const checkbox = document.createElement('input');
            checkbox.setAttribute('type', 'checkbox');
            checkbox.setAttribute('id', 'bombToggle');
            container.appendChild(label);
            container.appendChild(checkbox);
        }
        if (gameInformation.wallAllowed === true) {
            const container = document.querySelector('.wallDiv');
            const label = document.createElement('label');
            label.setAttribute('for', 'wallToggle');
            label.textContent = 'Use wall?';
            const checkbox = document.createElement('input');
            checkbox.setAttribute('type', 'checkbox');
            checkbox.setAttribute('id', 'wallToggle');
            container.appendChild(label);
            container.appendChild(checkbox);
        }

        intervalId = setInterval(updateBoard, 100);
    })
    .catch((error) => {
        output.appendChild(document.createTextNode(error));
    });


function makeTable(row, column) {
    let table = document.createElement("table");
    for (let i = 0; i < row; i++) {
        cells[i] = [];
        let tr = document.createElement("tr");
        tr.className = `tr_grid_${i}`;
        for (let j = 0; j < column; j++) {
            let td = document.createElement("td");
            td.className = `td_grid td_${i}_${j}`;
            td.appendChild(document.createTextNode(""));
            tr.appendChild(td);
            cells[i].push(td);
        }
        table.appendChild(tr);
    }
    return table;
}

function discTable(column){
    let table2 = document.createElement("discTable");
    let tr_disc = document.createElement("tr");
    for (let i =0; i < column; i++){
        let td_disc = document.createElement("td");
        td_disc.className = `td_disc2`;
        let span = document.createElement("span");
        span.className = `dot dot_${i}`;
        td_disc.appendChild(span);
        tr_disc.appendChild(td_disc);
    }
    table2.appendChild(tr_disc);
    return table2;
}

async function getGameInformation() {
    try {
        const response = await fetch(url, {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token")
            }
        });

        if (response.status === 200) {
            return await response.json();
        } else {
            errorMessage(response.statusText);
        }
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

async function makeMove(column) {
    if (finishedBoolean) {
        return;
    }

    const possibleMoves = await getPossibleMoves();
    const gameInformation = await getGameInformation();
    let columnToPlay;
    let type;
    let discType;
    const popOutCheckbox = document.getElementById('popoutToggle');
    const anvilCheckbox = document.getElementById('anvilToggle');
    const bombCheckbox = document.getElementById('bombToggle');
    const wallCheckbox = document.getElementById('wallToggle');

    if (gameInformation.popOutAllowed === true && gameInformation.anvilAllowed === true) {
        if (anvilCheckbox.checked && popOutCheckbox.checked) {
            errorMessage("Can not play a popout and an anvil at the same time.");
            return
        }
    }
    if (gameInformation.popOutAllowed === true && gameInformation.bombAllowed === true) {
        if (bombCheckbox.checked && popOutCheckbox.checked) {
            errorMessage("Can not play a bomb and a popout at the same time.");
            return
        }
    }
    if (gameInformation.popOutAllowed === true && gameInformation.wallAllowed === true) {
        if (wallCheckbox.checked && popOutCheckbox.checked) {
            errorMessage("Can not play a popout and a wall at the same time.");
            return
        }
    }
    if (gameInformation.anvilAllowed === true && gameInformation.bombAllowed === true) {
        if (bombCheckbox.checked && anvilCheckbox.checked) {
            errorMessage("Can not play a bomb and an anvil at the same time.");
            return
        }
    }
    if (gameInformation.anvilAllowed === true && gameInformation.wallAllowed === true) {
        if (wallCheckbox.checked && anvilCheckbox.checked) {
            errorMessage("Can not play a wall and an anvil at the same time.");
            return
        }
    }
    if (gameInformation.bombAllowed === true && gameInformation.wallAllowed === true) {
        if (wallCheckbox.checked && bombCheckbox.checked) {
            errorMessage("Can not play a wall and a bomb at the same time.");
            return
        }
    }

    if (gameInformation.popOutAllowed === true && popOutCheckbox.checked) {
        type = 2;
        discType = 2;
    } else if (gameInformation.anvilAllowed === true && anvilCheckbox.checked) {
        type = 3;
        discType = 3;
    } else if (gameInformation.bombAllowed === true && bombCheckbox.checked) {
        type = 4;
        discType = 4;
    } else if (gameInformation.wallAllowed === true && wallCheckbox.checked) {
        type = 5;
        discType = 5;
    } else {
        type = 1;
        discType = 1;
    }
    console.log(possibleMoves);
    let playerToPlay = gameInformation.playerToPlayId === gameInformation.player1.id ? gameInformation.player1 : gameInformation.player2;
    for (let i = 0; i < possibleMoves.length; i++) {
        let move = possibleMoves[i];
        if (move.column.toString() === column.toString() && move.type.toString() === type.toString()) {
            columnToPlay = move.column;
            break;
        }
    }
    if (columnToPlay !== undefined) {
        fetch(url + "/move", {
            method: "POST",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json;',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token")
            },
            body: JSON.stringify({
                type: type,
                discType: discType,
                column: columnToPlay
            })
        }).then(async function (response) {
            if (response.status === 200) {
                if (sessionStorage.getItem("singlePlayer") === "true" && !finishedBoolean) {
                    if (type !== 5) {
                        setTimeout(async () => {
                            await makeComputerMove();
                        }, 500);
                    }
                }
            } else {
                errorMessage("You can not make this move at this time.");
            }
        })
    } else {
        if (gameInformation.popOutAllowed === false && type === 2) {
            errorMessage("This game does not allow popouts.");
        }
        else if (gameInformation.anvilAllowed === false && type === 3) {
            errorMessage("This game does not allow anvil disks.");
        }
        else if (gameInformation.bombAllowed === false && type === 4) {
            errorMessage("This game does not allow bombs.");
        }
        else if (gameInformation.wallAllowed === false && type === 5) {
            errorMessage("This game does not allow walls.");
        }
        else if (gameInformation.popOutAllowed === true && type === 2) {
            if (hasSpecialDisksLeftOfSort(playerToPlay.specialDiscs, type) < 1) {
                errorMessage("You do not have any popouts left.");
            } else {
                errorMessage("You can only popout a disk of your own.");
            }
        }
        else if (gameInformation.anvilAllowed === true && type === 3) {
            if (hasSpecialDisksLeftOfSort(playerToPlay.specialDiscs, type) < 1) {
                errorMessage("You do not have any anvil disks left.");
            } else {
                errorMessage("You can not make this move at this time.");
            }
        }
        else if (gameInformation.bombAllowed === true && type === 4) {
            if (hasSpecialDisksLeftOfSort(playerToPlay.specialDiscs, type) < 1) {
                errorMessage("You do not have any bombs left.");
            } else {
                errorMessage("You can not make this move at this time.");
            }
        }
        else if (gameInformation.wallAllowed === true && type === 5) {
            if (hasSpecialDisksLeftOfSort(playerToPlay.specialDiscs, type) < 1) {
                errorMessage("You do not have any walls left.");
            } else {
                errorMessage("You have to place a normal disk after a wall special move.");
            }
        }
        else {
            if (gameInformation.wallAllowed === true && type === 1) {
                if (possibleMoves.length === 0) {
                    errorMessage("It's not your turn.");
                } else {
                    errorMessage("You can not make a winning move with the wall second disk.");
                }
            } else {
                errorMessage("It's not your turn.");
            }
        }
    }
}

async function getPossibleMoves() {
    try {
        const response = await fetch(url + "/possible-moves", {
            method: "GET",
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token")
            }
        });

        if (response.status === 200) {
            return await response.json();
        } else {
            errorMessage(response.statusText);
        }
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

async function updateBoard() {

    const gameInformation = await getGameInformation();
    cells = gameInformation.grid.cells;
    for (let i = 0; i < cells.length; i++) {
        for (let j = 0; j < cells[0].length; j++) {
            let vakje = document.getElementsByClassName("td_"+ i.toString() + "_" + j.toString());
            if (cells[i][j] != null) {
                vakje[0].style.backgroundColor = cells[i][j].Color === 1 ? 'red' : 'yellow';
                if (cells[i][j].Type === 3) {
                    vakje[0].style.backgroundImage = "url('assets/anvil.png')";
                    vakje[0].style.backgroundSize = "cover";
                    vakje[0].style.backgroundPosition = "center";
                    vakje[0].style.backgroundRepeat = "no-repeat";
                }
                else if (cells[i][j].Type === 5) {
                    vakje[0].style.backgroundImage = "url('assets/wall.png')";
                    vakje[0].style.backgroundSize = "cover";
                    vakje[0].style.backgroundPosition = "center";
                    vakje[0].style.backgroundRepeat = "no-repeat";
                }
                else {
                    vakje[0].style.backgroundImage = "";
                    vakje[0].style.backgroundSize = "";
                    vakje[0].style.backgroundPosition = "";
                    vakje[0].style.backgroundRepeat = "";
                }
            } else {
                vakje[0].style.backgroundColor = 'white';
            }
        }
    }

    if (gameInformation.finished) {
        if (!finishedBoolean) {
            await finishGame();
        }
    }
    
    const root = document.querySelector(':root');
    if (gameInformation.playerToPlayId === gameInformation.player1.id) {
        root.style.setProperty('--playerToPlayColor', gameInformation.player1.color === 1 ? 'red' : 'yellow');
        playerToPlayText.textContent = "It's " + gameInformation.player1.name + "'s turn!";
    } else {
        root.style.setProperty('--playerToPlayColor', gameInformation.player2.color === 1 ? 'red' : 'yellow');
        playerToPlayText.textContent = "It's " + gameInformation.player2.name + "'s turn!";
    }

    player1Name.textContent =
        gameInformation.player1.name.charAt(0).toUpperCase() + gameInformation.player1.name.slice(1) + " has:\n" +
        gameInformation.player1.numberOfNormalDiscs + " normal disks\n" +
        hasSpecialDisksLeftOfSort(gameInformation.player1.specialDiscs, 2) + " popout(s)\n" +
        hasSpecialDisksLeftOfSort(gameInformation.player1.specialDiscs, 3) + " anvil disk(s)\n" +
        hasSpecialDisksLeftOfSort(gameInformation.player1.specialDiscs, 4) + " bomb(s)\n" +
        hasSpecialDisksLeftOfSort(gameInformation.player1.specialDiscs, 5) + " wall(s)";

    player2Name.textContent =
        gameInformation.player2.name.charAt(0).toUpperCase() + gameInformation.player2.name.slice(1) + " has:\n" +
        gameInformation.player2.numberOfNormalDiscs + " normal disks\n" +
        hasSpecialDisksLeftOfSort(gameInformation.player2.specialDiscs, 2) + " popout(s)\n" +
        hasSpecialDisksLeftOfSort(gameInformation.player2.specialDiscs, 3) + " anvil disk(s)\n" +
        hasSpecialDisksLeftOfSort(gameInformation.player2.specialDiscs, 4) + " bomb(s)\n" +
        hasSpecialDisksLeftOfSort(gameInformation.player2.specialDiscs, 5) + " wall(s)";
}

function errorMessage(msg){
    error.textContent = msg;
    error.style.color = "red";
    setTimeout(clearError, 3000);
}

function clearError() {
    if (!finishedBoolean) {
        error.textContent = "";
    }
}

async function finishGame() {
    clearInterval(intervalId);
    finishedBoolean = true;

    const winningTextContainer = document.querySelector('.winningDiv')
    const winningText = document.createElement("p");
    winningText.setAttribute("id", "winningText");

    const image = document.createElement("img");
    image.src = "assets/party-popper.png";
    image.alt = "popper";
    image.width = 50;
    image.height = 50;

    const image2 = document.createElement("img");
    image2.src = "assets/party-popper.png";
    image2.alt = "popper";
    image2.width = 50;
    image2.height = 50;

    const gameInformation = await getGameInformation();
    const winningConnections = gameInformation.grid.winningConnections;

    let redWon = false;
    let yellowWon = false;

    for (let i = 0; i < winningConnections.length; i++) {
        if (winningConnections[i].color === 1) {
            redWon = true;
        } else if (winningConnections[i].color === 2){
            yellowWon = true;
        }
    }

    if ((redWon && yellowWon) || (!redWon && !yellowWon)) {
        winningText.textContent = "Game ended in a draw";
        winningTextContainer.appendChild(winningText);
        error.style.color = "blue";
    } else if (redWon) {
        if (gameInformation.player1.color === 1) {
            winningTextContainer.appendChild(image);
            winningText.textContent = "Game was won by " + gameInformation.player1.name.charAt(0).toUpperCase() + gameInformation.player1.name.slice(1) + ", playing the red disks.";
            winningTextContainer.appendChild(winningText);
            winningTextContainer.appendChild(image2);
        } else {
            winningTextContainer.appendChild(image);
            winningText.textContent = "Game was won by " + gameInformation.player2.name.charAt(0).toUpperCase() + gameInformation.player2.name.slice(1) + ", playing the red disks.";
            winningTextContainer.appendChild(winningText);
            winningTextContainer.appendChild(image2);
        }
        error.style.color = "red";
    } else {
        if (gameInformation.player1.color === 2) {
            winningTextContainer.appendChild(image);
            winningText.textContent = "Game was won by " + gameInformation.player1.name.charAt(0).toUpperCase() + gameInformation.player1.name.slice(1) + ", playing the yellow disks.";
            winningTextContainer.appendChild(winningText);
            winningTextContainer.appendChild(image2);
        } else {
            winningTextContainer.appendChild(image);
            winningText.textContent = "Game was won by " + gameInformation.player2.name.charAt(0).toUpperCase() + gameInformation.player2.name.slice(1) + ", playing the yellow disks.";
            winningTextContainer.appendChild(winningText);
            winningTextContainer.appendChild(image2);
        }
        error.style.color = "yellow";
    }

    console.log(winningConnections);

    winningConnections.forEach(function(connection) {
        let fromRow = connection.from.row;
        let fromColumn = connection.from.column;
        let toRow = connection.to.row;
        let toColumn = connection.to.column;

        let minRow = Math.min(fromRow, toRow);
        let minColumn = Math.min(fromColumn, toColumn);
        let maxRow = Math.max(fromRow, toRow);
        let maxColumn = Math.max(fromColumn, toColumn);

        for (let i = minRow; i <= maxRow; i++) {
            for (let j = minColumn; j <= maxColumn; j++) {
                if (pointOnLine(i, j, fromRow, fromColumn, toRow, toColumn, minRow, minColumn, maxRow, maxColumn)) {
                    let vakje = document.getElementsByClassName("td_" + i.toString() + "_" + j.toString());
                    vakje[0].classList.add('highlighted');
                }
            }
        }
    });

    const container = document.querySelector('.leaveDiv');
    const leaveButton = document.createElement('button');
    leaveButton.setAttribute('id', 'leaveButton');
    leaveButton.textContent = 'Leave Game';
    container.appendChild(leaveButton);
    leaveButton.addEventListener("click", function () {
        window.location.href = "waitingroom.html"
    });
}

function pointOnLine(x0, y0, x1, y1, x2, y2, minX, minY, maxX, maxY) {
    //Horizontal
    if (x1 === x2) {
        return x0 === x1 && minY <= y0 <= maxY;
    }
    //Vertical
    if (y1 === y2) {
        return y0 === y1 && minX <= x0 <= maxX;
    }
    // Diagonal
    const deltaX = x2 - x1;
    const deltaY = y2 - y1;
    if (deltaX * (y0 - y1) === deltaY * (x0 - x1)) {
        if (minX <= x0 && x0 <= maxX && minY <= y0 && y0 <= maxY) {
            return minX <= x0 && x0 <= maxX && minY <= y0 && y0 <= maxY;
        }
    }

    return false;
}

async function makeComputerMove() {
    if (finishedBoolean) {
        return;
    }
    fetch(url + "/computerMove", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json;',
            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
        }
    }).then(function (response) {
        if (response.status === 200) {
            updateBoard();
        } else {
            errorMessage(response.status);
        }
    })
}

function hasSpecialDisksLeftOfSort(specialDiscs, type) {
    let count = 0;
    for (let i = 0; i < specialDiscs.length; i++) {
        if (specialDiscs[i].type === type) {
            count++;
        }
    }
    return count;
}


