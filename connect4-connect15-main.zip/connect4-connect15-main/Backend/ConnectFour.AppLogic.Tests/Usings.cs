global using NUnit.Framework;
global using Guts.Client.Core;
global using Moq;