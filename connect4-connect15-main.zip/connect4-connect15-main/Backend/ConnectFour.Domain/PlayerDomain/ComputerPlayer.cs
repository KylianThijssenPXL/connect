﻿using ConnectFour.Domain.GameDomain.Contracts;
using ConnectFour.Domain.GridDomain;
using ConnectFour.Domain.GridDomain.Contracts;
using ConnectFour.Domain.PlayerDomain.Contracts;

namespace ConnectFour.Domain.PlayerDomain;

/// <inheritdoc cref="IPlayer"/>
public class ComputerPlayer : PlayerBase, IPlayer
{
    //Iniating computerPlayer
    public ComputerPlayer(DiscColor color, int numberOfNormalDiscs, IGamePlayStrategy strategy) : base(Guid.NewGuid(), "Computer", color, numberOfNormalDiscs)
    {
        this.NumberOfNormalDiscs = numberOfNormalDiscs;
        this.Id = Guid.NewGuid();
        this.Name = "Computer";
        this.Color = color;
        this.SpecialDiscs = new List<IDisc>();
        this.Strategy = strategy;
    }

    //copy computerPlayer
    public ComputerPlayer(Guid playerId, DiscColor color, int numberOfNormalDiscs, IGamePlayStrategy strategy, IList<IDisc> specialDiscs) : base(Guid.NewGuid(), "Computer", color, numberOfNormalDiscs)
    {
        this.NumberOfNormalDiscs = numberOfNormalDiscs;
        this.Id = playerId;
        this.Name = "Computer";
        this.Color = color;
        this.Strategy = strategy;
        this.SpecialDiscs = new List<IDisc>();
        for (int i = 0; i < specialDiscs.Count; i++)
        {
            this.SpecialDiscs.Add(specialDiscs[i]);
        }
    }

    public Guid Id { get; }

    public string Name { get; }

    public DiscColor Color { get; }

    public int NumberOfNormalDiscs { get; set; }

    public IList<IDisc> SpecialDiscs { get; }

    public IGamePlayStrategy Strategy { get; }

    public void AddDisc(DiscType discType, int count)
    {
        if (discType == DiscType.Normal)
        {
            this.NumberOfNormalDiscs++;
        }
        else
        {
            for (int i = 0; i < count; i++)
            {
                this.SpecialDiscs.Add(new Disc(discType, this.Color));
            }
        }
    }

    public bool HasDisk(DiscType discType)
    {
        if (discType.Equals(DiscType.Normal))
        {
            return this.NumberOfNormalDiscs > 0;
        }
        else
        {
            foreach (IDisc disk in this.SpecialDiscs)
            {
                if (disk.Type == discType)
                {
                    return true;
                }
            }
            return false;
        }
    }

    public void RemoveDisc(DiscType discType)
    {
        if (this.HasDisk(discType))
        {
            if (discType == DiscType.Normal)
            {
                this.NumberOfNormalDiscs--;
            }
            else
            {
                foreach (var disc in this.SpecialDiscs)
                {
                    if (disc.Type == discType)
                    {
                        this.SpecialDiscs.Remove(disc);
                        break;
                    }
                }
            }
        }
        else
        {
            throw new InvalidOperationException();
        }
    }
}