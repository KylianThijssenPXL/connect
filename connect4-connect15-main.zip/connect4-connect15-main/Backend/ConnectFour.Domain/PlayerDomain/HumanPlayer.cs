﻿using ConnectFour.Domain.GridDomain;
using ConnectFour.Domain.GridDomain.Contracts;
using ConnectFour.Domain.PlayerDomain.Contracts;

namespace ConnectFour.Domain.PlayerDomain;

/// <inheritdoc cref="IPlayer"/>
public class HumanPlayer : PlayerBase, IPlayer
{
    public HumanPlayer(Guid userId, string name, DiscColor color, int numberOfNormalDiscs, IList<IDisc> specialDiscs) : base(userId, name, color, numberOfNormalDiscs) 
    { 
        this.NumberOfNormalDiscs = numberOfNormalDiscs;
        this.Id = userId;
        this.Name = name;
        this.Color = color;
        this.SpecialDiscs = new List<IDisc>();
        if (specialDiscs != null)
        {
            for (int i = 0; i < specialDiscs.Count; i++)
            {
                this.SpecialDiscs.Add(specialDiscs[i]);
            }
        }
    }

    public HumanPlayer(Guid userId, string name, DiscColor color, int numberOfNormalDiscs) : base(userId, name, color, numberOfNormalDiscs)
    {
        this.NumberOfNormalDiscs = numberOfNormalDiscs;
        this.Id = userId;
        this.Name = name;
        this.Color = color;
        this.SpecialDiscs = new List<IDisc>();
    }

    public Guid Id { get; }

    public string Name { get; }

    public DiscColor Color { get; }

    public int NumberOfNormalDiscs { get; set; }

    public IList<IDisc> SpecialDiscs { get; }

    public void AddDisc(DiscType discType, int count = 1)
    {
        if (discType == DiscType.Normal)
        {
            this.NumberOfNormalDiscs++;
        }
        else
        {
            for (int i = 0; i < count; i++)
            {
                this.SpecialDiscs.Add(new Disc(discType, this.Color));
            }
        }
    }

    public bool HasDisk(DiscType discType)
    {
        if (discType.Equals(DiscType.Normal))
        {
            return this.NumberOfNormalDiscs > 0;
        }
        else
        {
            foreach (IDisc disk in this.SpecialDiscs)
            {
                if (disk.Type == discType)
                {
                    return true;
                }
            }
            return false;
        }
    }

    public void RemoveDisc(DiscType discType)
    {
        if (this.HasDisk(discType))
        {
            if (discType == DiscType.Normal)
            {
                this.NumberOfNormalDiscs--;
            } 
            else
            {
                foreach(var disc in this.SpecialDiscs)
                {
                    if (disc.Type == discType)
                    {
                        this.SpecialDiscs.Remove(disc);
                        break;
                    }
                }
            }
        }
        else
        {
            throw new InvalidOperationException();
        }
    }
}