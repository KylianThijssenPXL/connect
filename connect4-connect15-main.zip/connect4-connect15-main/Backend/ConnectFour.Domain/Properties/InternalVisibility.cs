﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("ConnectFour.Domain.Tests")]
[assembly: InternalsVisibleTo("ConnectFour.Api")]