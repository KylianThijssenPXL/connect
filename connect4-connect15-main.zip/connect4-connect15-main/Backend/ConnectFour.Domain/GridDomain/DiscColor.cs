﻿namespace ConnectFour.Domain.GridDomain;

public enum DiscColor
{
    Red = 1,
    Yellow = 2
}