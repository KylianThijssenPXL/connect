﻿using ConnectFour.Domain.GameDomain;
using ConnectFour.Domain.GameDomain.Contracts;
using ConnectFour.Domain.GridDomain.Contracts;
using ConnectFour.Domain.PlayerDomain.Contracts;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;

namespace ConnectFour.Domain.GridDomain;

/// <inheritdoc cref="IGrid"/>
public class Grid : IGrid
{
    public Grid(GameSettings settings = null)
    {
        settings = settings ?? new GameSettings();
        this.NumberOfRows = settings.GridRows;
        this.NumberOfColumns = settings.GridColumns;
        this.WinningConnectSize = settings.ConnectionSize;
        List<IConnection> winningConnections = new List<IConnection>();
        this.WinningConnections = winningConnections;
        this.Cells = new IDisc[settings.GridRows, settings.GridColumns];

        this.PopOutAllowed = settings.EnablePopOut;
        this.AnvilAllowed = settings.EnableAnvil;
        this.BombAllowed = settings.EnableBomb;
        this.WallAllowed = settings.EnableWall;
    }

    /// <summary>
    /// Creates a grid that is a copy of an other grid.
    /// </summary>
    /// <remarks>
    /// This is an EXTRA. Not needed to implement the minimal requirements.
    /// To make the mini-max algorithm for an AI game play strategy work, this constructor should be implemented.
    /// </remarks>
    public Grid(IGrid otherGrid)
    {
        this.NumberOfRows = otherGrid.NumberOfRows;
        this.NumberOfColumns = otherGrid.NumberOfColumns;
        this.WinningConnectSize = otherGrid.WinningConnectSize;
        this.WinningConnections = new List<IConnection>(otherGrid.WinningConnections);
        this.Cells = new IDisc[NumberOfRows, NumberOfColumns];
        for (int row = 0; row < NumberOfRows; row++)
        {
            for (int col = 0; col < NumberOfColumns; col++)
            {
                this.Cells[row, col] = otherGrid.Cells[row, col];
            }
        }

        this.PopOutAllowed = otherGrid.PopOutAllowed;
        this.AnvilAllowed = otherGrid.AnvilAllowed;
        this.BombAllowed = otherGrid.BombAllowed;
        this.WallAllowed = otherGrid.WallAllowed;
    }

    public int NumberOfRows { get; }

    public int NumberOfColumns { get; }

    public int WinningConnectSize { get; }

    public IDisc[,] Cells { get; }
    public List<IConnection> WinningConnections { get; }

    public bool PopOutAllowed { get; }

    public bool AnvilAllowed { get; }

    public bool BombAllowed { get; }

    public bool WallAllowed { get; }

    public void WallDisc(IDisc disc, int column)
    {
        for (int row = this.NumberOfRows - 1; row >= 0; row--)
        {
            if (this.Cells[row, column] == null)
            {
                this.Cells[row, column] = disc;
                CheckForConnections(this.WinningConnectSize);
                return;
            }
        }
        throw new InvalidOperationException();
    }


    public void BombDisc(IDisc disc, IGame game)
    {
        for (int column = 0; column < NumberOfColumns; column++)
        {
            if (this.Cells[this.NumberOfRows - 1, column] == null)
            {
                continue;
            }
            if (disc.Color == this.Cells[this.NumberOfRows - 1, column].Color)
            {
                continue;
            }
            if (game != null) 
            {
                if (this.Cells[this.NumberOfRows - 1, column].Color == DiscColor.Red)
                {
                    game.Player1.AddDisc(DiscType.Normal, 1);
                }
                else
                {
                    game.Player2.AddDisc(DiscType.Normal, 1);
                }
            }
            for (int row = this.NumberOfRows - 1; row > 0; row--)
            {
                if (this.Cells[row - 1, column] != null)
                {
                    this.Cells[row, column] = this.Cells[row - 1, column];
                    this.Cells[row - 1, column] = null;
                }
                else if (this.Cells[row, column] != null)
                {
                    this.Cells[row, column] = null;
                }
                else
                {
                    break;
                }
            }
        }
        CheckForConnections(this.WinningConnectSize);
    }
    public void AnvilDisc(IDisc disc, int column, IGame game)
    {
        for (int row = 0; row < this.NumberOfRows; row++)
        {
            if (this.Cells[row, column] != null)
            {
                if (game != null) 
                {
                    if (this.Cells[row, column].Color == DiscColor.Red)
                    {
                        game.Player1.AddDisc(DiscType.Normal, 1);
                    }
                    else
                    {
                        game.Player2.AddDisc(DiscType.Normal, 1);
                    }
                }
                this.Cells[row, column] = null;
                if (row == (this.NumberOfRows - 1))
                {
                    this.Cells[row, column] = new Disc(DiscType.Anvil, disc.Color);
                }
            }
        }
        CheckForConnections(this.WinningConnectSize);
    }

    public void PopOutDisc(IDisc disc, int column)
    {
        for (int row = this.NumberOfRows - 1; row > 0; row--)
        {
            if (this.Cells[row - 1, column] != null)
            {
                this.Cells[row, column] = this.Cells[row - 1, column];
                this.Cells[row - 1, column] = null;
                CheckForConnections(this.WinningConnectSize);
            }
            else
            {
                return;
            }
        }
    }

    public void SlideInDisc(IDisc disc, int column)
    {
        for (int row = this.NumberOfRows - 1; row >= 0; row--)
        {
            if (this.Cells[row,column] == null)
            {
                this.Cells[row,column] = disc;
                CheckForConnections(this.WinningConnectSize);
                return;
            }
        }
        throw new InvalidOperationException();
    }

    public void CheckForConnections(int connectionSize)
    {
        // Horizontal
        int size = 0;
        DiscColor color = 0;
        for (int row = 0; row < this.NumberOfRows; row++)
        {
            size = 0;
            color = 0;
            for (int column = 0; column < this.NumberOfColumns; column++)
            {
                if (this.Cells[row, column] == null)
                {
                    size = 0;
                    color = 0;
                    continue;
                }
                if (color == 0)
                {
                    if (this.NumberOfColumns - column < connectionSize)
                    {
                        break;
                    }
                    color = this.Cells[row, column].Color;
                    size++;
                    continue;
                }
                if (this.Cells[row, column].Color != color)
                {
                    size = 1;
                    color = this.Cells[row, column].Color;
                    continue;
                }
                if (this.Cells[row, column].Color == color)
                {
                    size++;
                }
                if (size == connectionSize)
                {
                    Connection winningConnection = new Connection(row, column - connectionSize + 1, row, column, color);
                    bool found = false;
                    for (int i = 0; i < this.WinningConnections.Count; i++)
                    {
                        if (this.WinningConnections[i].Equals(winningConnection))
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        this.WinningConnections.Add(winningConnection);
                    }
                }
            }
        }

        //Vertical
        for (int column = 0; column < this.NumberOfColumns; column++)
        {
            size = 0;
            color = 0;
            for (int row = 0; row < this.NumberOfRows; row++)
            {
                if (this.Cells[row, column] == null)
                {
                    size = 0;
                    color = 0;
                    continue;
                }
                if (color == 0)
                {
                    if (row + connectionSize > this.NumberOfRows)
                    {
                        break;
                    }
                    color = this.Cells[row, column].Color;
                    size++;
                    continue;
                }
                if (this.Cells[row, column].Color != color)
                {
                    size = 1;
                    color = this.Cells[row, column].Color;
                    continue;
                }
                if (this.Cells[row, column].Color == color)
                {
                    size++;
                }
                if (size == connectionSize)
                {
                    Connection winningConnection = new Connection(row - connectionSize + 1, column, row, column, color);
                    bool found = false;
                    for (int i = 0; i < this.WinningConnections.Count; i++)
                    {
                        if (this.WinningConnections[i].Equals(winningConnection))
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        this.WinningConnections.Add(winningConnection);
                    }
                }
            }
        }

        //Diagonal top left to bottom right
        for (int row = 0; row < this.NumberOfRows; row++)
        {
            for (int column = 0; column < this.NumberOfColumns; column++)
            {
                if (row + connectionSize > this.NumberOfRows || column + connectionSize > this.NumberOfColumns)
                {
                    break;
                }

                size = 0;
                color = 0;
                int startRow = row;
                int startColumn = column;

                while (startRow < this.NumberOfRows && startColumn < this.NumberOfColumns)
                {
                    if (this.Cells[startRow, startColumn] == null)
                    {
                        size = 0;
                        color = 0;
                    }
                    else if (color == 0)
                    {
                        color = this.Cells[startRow, startColumn].Color;
                        size++;
                    }
                    else if (this.Cells[startRow, startColumn].Color == color)
                    {
                        size++;
                        if (size == connectionSize)
                        {
                            Connection winningConnection = new Connection(startRow - connectionSize + 1, startColumn - connectionSize + 1, startRow, startColumn, color);
                            bool found = false;
                            for (int i = 0; i < this.WinningConnections.Count; i++)
                            {
                                if (this.WinningConnections[i].Equals(winningConnection))
                                {
                                    found = true;
                                    break;
                                }
                            }
                            if (!found)
                            {
                                this.WinningConnections.Add(winningConnection);
                            }
                        }
                    }
                    else
                    {
                        size = 1;
                        color = this.Cells[startRow, startColumn].Color;
                    }

                    startRow++;
                    startColumn++;
                }
            }
        }

        // Diagonal bottom left to top right
        for (int row = this.NumberOfRows - 1; row >= connectionSize - 1; row--)
        {
            for (int column = 0; column <= this.NumberOfColumns - connectionSize; column++)
            {
                size = 0;
                color = 0;
                int startRow = row;
                int startColumn = column;

                while (startRow >= 0 && startColumn < this.NumberOfColumns)
                {
                    if (this.Cells[startRow, startColumn] == null)
                    {
                        size = 0;
                        color = 0;
                    }
                    else if (color == 0)
                    {
                        color = this.Cells[startRow, startColumn].Color;
                        size++;
                    }
                    else if (this.Cells[startRow, startColumn].Color == color)
                    {
                        size++;
                        if (size == connectionSize)
                        {
                            Connection winningConnection = new Connection(startRow + connectionSize - 1, startColumn - connectionSize + 1, startRow, startColumn, color);
                            bool found = false;
                            for (int i = 0; i < this.WinningConnections.Count; i++)
                            {
                                if (this.WinningConnections[i].Equals(winningConnection))
                                {
                                    found = true;
                                    break;
                                }
                            }
                            if (!found)
                            {
                                this.WinningConnections.Add(winningConnection);
                            }
                        }
                    }
                    else
                    {
                        size = 1;
                        color = this.Cells[startRow, startColumn].Color;
                    }

                    startRow--;
                    startColumn++;
                }
            }
        }
    }

    public int CountFreeSlots()
    {
        int count = 0;
        for (int column = 0; column < this.NumberOfColumns; column++)
        {
            for (int row = 0; row < this.NumberOfRows; row++)
            {
                if (this.Cells[row,column] == null)
                {
                    count++;
                }
            }
        }
        return count;
    }

    public bool IsFull()
    {
        return CountFreeSlots() == 0;
    }

    public bool IsEmpty()
    {
        return CountFreeSlots() == (this.NumberOfRows * this.NumberOfColumns);
    }
}