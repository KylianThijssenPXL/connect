﻿namespace ConnectFour.Domain.GridDomain;

public enum DiscType
{
    Normal = 1,
    Popout = 2,
    Anvil = 3,
    Bomb = 4,
    Wall = 5,
}