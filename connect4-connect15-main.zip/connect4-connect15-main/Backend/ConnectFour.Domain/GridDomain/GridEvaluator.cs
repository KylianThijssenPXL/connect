﻿using ConnectFour.Domain.GameDomain;
using ConnectFour.Domain.GameDomain.Contracts;
using ConnectFour.Domain.GridDomain.Contracts;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Diagnostics;

namespace ConnectFour.Domain.GridDomain;

/// <inheritdoc cref="IGridEvaluator"/>
public class GridEvaluator : IGridEvaluator
{
    public int CalculateScore(IGrid grid, DiscColor maximizingColor)
    {
        int score = 0;
        int ROW_COUNT = grid.NumberOfRows;
        int COLUMN_COUNT = grid.NumberOfColumns;
        int WINDOW_LENGTH = grid.WinningConnectSize;
        IDisc[,] board = grid.Cells;
        DiscColor minimizingColor = maximizingColor == DiscColor.Red ? DiscColor.Yellow : DiscColor.Red;

        if (grid.WinningConnections.Count > 0)
        {
            bool maximizingPlayerWins = false;
            bool minimizingPlayerWins = false;
            for (int i = 0; i < grid.WinningConnections.Count; i++)
            {
                if (grid.WinningConnections[i].Color == maximizingColor)
                {
                    maximizingPlayerWins = true;
                }
                else
                {
                    minimizingPlayerWins = true;
                }
            }
            if (maximizingPlayerWins && minimizingPlayerWins)
            {
                return 0;
            }
            else if (maximizingPlayerWins)
            {
                return int.MaxValue;
            }
            else
            {
                return int.MinValue;
            }
        }
        if (((Grid)grid).IsFull())
        {
            return 0;
        }

        // Score center column
        List<IDisc> center_array = new List<IDisc>();
        for (int i = 0; i < ROW_COUNT; i++)
        {
            center_array.Add(board[i, COLUMN_COUNT / 2]);
        }
        int center_count = center_array.Count(x => x != null && x.Color == maximizingColor);
        int center_count_opponent = center_array.Count(x => x != null && x.Color == minimizingColor);
        score += center_count * 3;
        score -= center_count_opponent * 2;

        // Score Horizontal
        for (int r = 0; r < ROW_COUNT; r++)
        {
            List<IDisc> row_array = new List<IDisc>();
            for (int c = 0; c < COLUMN_COUNT; c++)
            {
                row_array.Add(board[r, c]);
            }
            for (int c = 0; c < COLUMN_COUNT - 3; c++)
            {
                List<IDisc> window = row_array.GetRange(c, WINDOW_LENGTH);
                score += EvaluateWindow(window, maximizingColor);
            }
        }

        // Score Vertical
        for (int c = 0; c < COLUMN_COUNT; c++)
        {
            List<IDisc> col_array = new List<IDisc>();
            for (int r = 0; r < ROW_COUNT; r++)
            {
                col_array.Add(board[r, c]);
            }
            for (int r = 0; r < ROW_COUNT - 3; r++)
            {
                List<IDisc> window = col_array.GetRange(r, WINDOW_LENGTH);
                score += EvaluateWindow(window, maximizingColor);
            }
        }

        // Score positive sloped diagonal
        for (int r = 0; r < ROW_COUNT - 3; r++)
        {
            for (int c = 0; c < COLUMN_COUNT - 3; c++)
            {
                List<IDisc> window = new List<IDisc>();
                for (int i = 0; i < WINDOW_LENGTH; i++)
                {
                    window.Add(board[r + i, c + i]);
                }
                score += EvaluateWindow(window, maximizingColor);
            }
        }

        for (int r = 0; r < ROW_COUNT - 3; r++)
        {
            for (int c = 0; c < COLUMN_COUNT - 3; c++)
            {
                List<IDisc> window = new List<IDisc>();
                for (int i = 0; i < WINDOW_LENGTH; i++)
                {
                    window.Add(board[r + 3 - i, c + i]);
                }
                score += EvaluateWindow(window, maximizingColor);
            }
        }

        return score;
    }

    public int EvaluateWindow(List<IDisc> window, DiscColor maximizingColor)
    {
        DiscColor minimizingColor = maximizingColor == DiscColor.Red ? DiscColor.Yellow : DiscColor.Red;
        int score = 0;

        if (window.Count(x => x != null && x.Color == maximizingColor) == 4)
        {
            score += 100;
        }
        else if (window.Count(x => x != null && x.Color == maximizingColor) == 3 && window.Count(x => x == null) == 1)
        {
            score += 5;
        }
        else if (window.Count(x => x != null && x.Color == maximizingColor) == 2 && window.Count(x => x == null) == 2)
        {
            score += 2;
        }

        if (window.Count(x => x != null && x.Color == minimizingColor) == 3 && window.Count(x => x == null) == 1)
        {
            score -= 4;
        }

        return score;
    }
}