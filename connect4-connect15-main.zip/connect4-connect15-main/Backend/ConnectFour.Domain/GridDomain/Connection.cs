﻿using ConnectFour.Domain.GridDomain.Contracts;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Drawing;

namespace ConnectFour.Domain.GridDomain;

/// <inheritdoc cref="IConnection"/>
public class Connection : IConnection
{
    public static Connection Empty
    {
        get
        {
            return new Connection();
        }
    }

    public GridCoordinate From { get; }

    public GridCoordinate To { get; }

    public int Size { get; }

    public DiscColor Color { get; }

    public Connection(int rowFrom, int columnFrom, int rowTo, int columnTo, DiscColor color)
    {
        this.From = new GridCoordinate(rowFrom, columnFrom);
        this.To = new GridCoordinate(rowTo, columnTo);
        this.Color = color;
        this.Size = CalculateSize(From, To, color);
    }

    private Connection()
    {
        this.From = GridCoordinate.Empty;
        this.To = GridCoordinate.Empty;
        this.Color = DiscColor.Red;
        this.Size = 0;
    }

    private int CalculateSize(GridCoordinate From, GridCoordinate To, DiscColor color) 
    {
        if (From.Equals(To))
        {
            return 1;
        }
        if (From.Row == To.Row)
        {
            return Math.Max(From.Column, To.Column) - Math.Min(From.Column, To.Column) + 1;
        }
        if (From.Column == To.Column)
        {
            return Math.Max(From.Row, To.Row) - Math.Min(From.Row, To.Row) + 1;
        }
        return Convert.ToInt32(Math.Sqrt(Math.Pow((From.Row - To.Row),2) + Math.Pow((From.Column - To.Column), 2)));
    }

    public override bool Equals(object obj)
    {
        if (obj == null) return false;
        if (obj is Connection otherConnection)
        {
            if (otherConnection.To.Column !=  this.To.Column) return false;
            if (otherConnection.To.Row != this.To.Row) return false;
            if (otherConnection.From.Column != this.From.Column) return false;
            if (otherConnection.From.Row != this.From.Row) return false;
            if (otherConnection.Color != this.Color) return false;
            if (otherConnection.Size != this.Size) return false;
            else
            {
                return true;
            }
        } 
        else
        {
            return false;
        }
    }
}