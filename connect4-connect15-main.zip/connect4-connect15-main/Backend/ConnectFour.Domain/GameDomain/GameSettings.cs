﻿using System.ComponentModel;

namespace ConnectFour.Domain.GameDomain;

public class GameSettings
{
    /// <summary>
    /// If true, you will be automatically matched with another candidate in the waiting pool.
    /// </summary>
    [DefaultValue(true)]
    public bool AutoMatchCandidates { get; set; }

    /// <summary>
    /// If true, it is also possible to pop a disc out of the bottom of the grid (EXTRA).
    /// The default value is false.
    /// </summary>
    [DefaultValue(false)]
    public bool EnablePopOut { get; set; }

    /// <summary>
    /// Number of popouts a player gets at the start of the game.
    /// The default value is one.
    /// </summary>
    [DefaultValue(1)]
    public int PopOutCount { get; set; }

    /// <summary>
    /// If true, it is also possible drop in an anvil disk that pushes all the other disks out of the column it was dropped in. (EXTRA).
    /// The default value is false.
    /// </summary>
    [DefaultValue(false)]
    public bool EnableAnvil { get; set; }

    /// <summary>
    /// Number of anvils a player gets at the start of the game.
    /// The default value is one.
    /// </summary>
    [DefaultValue(1)]
    public int AnvilCount { get; set; }

    /// <summary>
    /// If true, it is also possible drop in a bomb, deleting all the opponent's disks on the last row. (EXTRA).
    /// The default value is false.
    /// </summary>
    [DefaultValue(false)]
    public bool EnableBomb { get; set; }

    /// <summary>
    /// Number of bombs a player gets at the start of the game.
    /// The default value is one.
    /// </summary>
    [DefaultValue(1)]
    public int BombCount { get; set; }

    /// <summary>
    /// If true, it is also possible drop in a wall, making it so you can play again, but the second disk can not create a winning connection. (EXTRA).
    /// The default value is false.
    /// </summary>
    [DefaultValue(false)]
    public bool EnableWall { get; set; }

    /// <summary>
    /// Number of walls a player gets at the start of the game.
    /// The default value is one.
    /// </summary>
    [DefaultValue(1)]
    public int WallCount { get; set; }

    /// <summary>
    /// Number of discs that need to be connected to win.
    /// The default value is four.
    /// </summary>
    [DefaultValue(4)]
    public int ConnectionSize { get; set; }

    /// <summary>
    /// Number of rows in the grid.
    /// The default value is 6.
    /// </summary>
    [DefaultValue(6)]
    public int GridRows { get; set; }

    /// <summary>
    /// Number of columns in the grid.
    /// The default value is 7.
    /// </summary>
    [DefaultValue(7)]
    public int GridColumns { get; set; }

    public GameSettings()
    {
        AutoMatchCandidates = true;
        EnablePopOut = false;
        EnableAnvil = false;
        EnableBomb = false;
        ConnectionSize = 4;
        GridRows = 6;
        GridColumns = 7;
    }
}