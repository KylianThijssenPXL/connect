﻿using ConnectFour.Domain.GameDomain.Contracts;
using ConnectFour.Domain.GridDomain;
using ConnectFour.Domain.GridDomain.Contracts;
using ConnectFour.Domain.PlayerDomain;
using ConnectFour.Domain.PlayerDomain.Contracts;

namespace ConnectFour.Domain.GameDomain;

/// <inheritdoc cref="IGameFactory"/>
internal class GameFactory : IGameFactory
{
    public GameFactory(IGamePlayStrategy gamePlayStrategy)
    {
        IGameFactory _gameFactory;

    }

    public IGame CreateNewSinglePlayerGame(GameSettings settings, User user)
    {
        HumanPlayer player1 = new HumanPlayer(user.Id, user.NickName, DiscColor.Red, settings.GridRows * settings.GridColumns / 2);
        ComputerPlayer player2 = new ComputerPlayer(DiscColor.Yellow, settings.GridRows * settings.GridColumns / 2, new MiniMaxGamePlayStrategy(new GridEvaluator(), 5));
        return new Game(player1, player2, new Grid(settings), settings.EnablePopOut, settings.PopOutCount, settings.EnableAnvil, settings.AnvilCount, settings.EnableBomb, settings.BombCount, settings.EnableWall, settings.WallCount);
    }

    public IGame CreateNewTwoPlayerGame(GameSettings settings, User user1, User user2)
    {
        if (user1.Id == user2.Id)
        {
            throw new InvalidOperationException();
        }
        else
        {
            HumanPlayer player1 = new HumanPlayer(user1.Id, user1.NickName, DiscColor.Red, settings.GridRows * settings.GridColumns / 2);
            HumanPlayer player2 = new HumanPlayer(user2.Id, user2.NickName, DiscColor.Yellow, settings.GridRows * settings.GridColumns / 2);
            return new Game(player1, player2, new Grid(settings), settings.EnablePopOut, settings.PopOutCount, settings.EnableAnvil, settings.AnvilCount, settings.EnableBomb, settings.BombCount, settings.EnableWall, settings.WallCount);
        }
    }
}