﻿using ConnectFour.Domain.GameDomain.Contracts;
using ConnectFour.Domain.GridDomain;
using ConnectFour.Domain.GridDomain.Contracts;
using ConnectFour.Domain.PlayerDomain;
using ConnectFour.Domain.PlayerDomain.Contracts;
using System.Collections.Generic;

namespace ConnectFour.Domain.GameDomain;

/// <inheritdoc cref="IGame"/>
internal class Game : IGame
{
    public Guid Id { get; }

    public IPlayer Player1 { get; }

    public IPlayer Player2 { get; }

    public Guid PlayerToPlayId { get; set; }

    public IGrid Grid { get; }

    public bool Finished
    {
        get { 
            if (!GetPlayerById(this.PlayerToPlayId).HasDisk(DiscType.Normal))
            {
                return true;
            }
            return this.Grid.WinningConnections.Count >= 1; 
        }
    }

    public bool PopOutAllowed { get; }

    public int PopOutCount { get; }

    public bool AnvilAllowed { get; }

    public int AnvilCount { get; }

    public bool BombAllowed { get; }

    public int BombCount { get; }

    public bool WallAllowed { get; }

    public int WallCount { get; }

    public IDisc LastDisc { get; set; }

    public Game(IPlayer player1, IPlayer player2, IGrid grid, bool popOutAllowed = false, int popOutCount = 1, bool anvilAllowed = false, int anvilCount = 1, bool bombAllowed = false, int bombCount = 1, bool wallAllowed = false, int wallCount = 1)
    {
        this.Player1 = player1;
        this.Player2 = player2;
        this.Grid = grid;
        this.PopOutAllowed = popOutAllowed;
        this.AnvilAllowed = anvilAllowed;
        this.BombAllowed = bombAllowed;
        this.WallAllowed = wallAllowed;
        this.PlayerToPlayId = player1.Id;
        this.Id = Guid.NewGuid();
        this.LastDisc = new Disc(DiscType.Normal, DiscColor.Red);
        if (popOutAllowed)
        {
            this.Player1.AddDisc(DiscType.Popout, popOutCount);
            this.Player2.AddDisc(DiscType.Popout, popOutCount);
        }
        if (anvilAllowed)
        {
            this.Player1.AddDisc(DiscType.Anvil, anvilCount);
            this.Player2.AddDisc(DiscType.Anvil, anvilCount);
        }
        if (bombAllowed)
        {
            this.Player1.AddDisc(DiscType.Bomb, bombCount);
            this.Player2.AddDisc(DiscType.Bomb, bombCount);
        }
        if (wallAllowed)
        {
            this.Player1.AddDisc(DiscType.Wall, wallCount);
            this.Player2.AddDisc(DiscType.Wall, wallCount);
        }
    }

    /// <summary>
    /// Creates a game that is a copy of an other game.
    /// </summary>
    /// <remarks>
    /// This is an EXTRA. Not needed to implement the minimal requirements.
    /// To make the mini-max algorithm for an AI game play strategy work, this constructor should be implemented.
    /// </remarks>
    public Game(IGame otherGame)
    {
        //TODO: make a copy of the players
        //TODO: make a copy of the grid
        //TODO: initialize the properties with the copies
        this.Player1 = new HumanPlayer(otherGame.Player1.Id, otherGame.Player1.Name,otherGame.Player1.Color,otherGame.Player1.NumberOfNormalDiscs, otherGame.Player1.SpecialDiscs);
        this.Player2 = new ComputerPlayer(otherGame.Player2.Id, otherGame.Player2.Color, otherGame.Player2.NumberOfNormalDiscs, new MiniMaxGamePlayStrategy(new GridEvaluator(), 5), otherGame.Player2.SpecialDiscs);
        this.Grid = new Grid(otherGame.Grid);
        this.PopOutAllowed = otherGame.PopOutAllowed;
        this.AnvilAllowed = otherGame.AnvilAllowed;
        this.BombAllowed = otherGame.BombAllowed;
        this.WallAllowed = otherGame.WallAllowed;
        this.PlayerToPlayId = otherGame.PlayerToPlayId;
        this.Id = otherGame.Id;
        this.LastDisc = otherGame.LastDisc;
    }

    public IReadOnlyList<IMove> GetPossibleMovesFor(Guid playerId)
    {
        List<IMove> list = new List<IMove>();
        IPlayer player = GetPlayerById(playerId);
        if (player == null)
        {
            throw new InvalidOperationException();
        }
        if (playerId != this.PlayerToPlayId)
        {
            return list;
        }
        if (this.Finished)
        {
            return list;
        }
        if (this.LastDisc.Type == DiscType.Wall)
        {
            for (int column = 0; column < this.Grid.NumberOfColumns; column++)
            {
                if (this.Grid.Cells[0, column] == null)
                {
                    IGame copyGame = new Game(this) as IGame;
                    copyGame.ExecuteMove(playerId, new Move(column, MoveType.SlideIn, DiscType.Normal));
                    if (player.HasDisk(DiscType.Normal) && copyGame.Grid.WinningConnections.Count == 0)
                    {
                        list.Add(new Move(column, MoveType.SlideIn, DiscType.Normal));
                    }
                }
            }
            return list;
        }
        for (int column = 0; column < this.Grid.NumberOfColumns; column++)
        {
            if (this.Grid.Cells[0, column] == null)
            {
                if (player.HasDisk(DiscType.Normal))
                {
                    list.Add(new Move(column, MoveType.SlideIn, DiscType.Normal));
                }
                if (player.HasDisk(DiscType.Wall))
                {
                    list.Add(new Move(column, MoveType.Wall, DiscType.Wall));
                }
            }
            if (this.Grid.Cells[this.Grid.NumberOfRows - 1, column] != null)
            {
                if (this.Grid.Cells[this.Grid.NumberOfRows - 1, column].Color == player.Color)
                {
                    if (player.HasDisk(DiscType.Popout) && this.PopOutAllowed)
                    {
                        list.Add(new Move(column, MoveType.PopOut, DiscType.Popout));
                    }
                }
                if (player.HasDisk(DiscType.Anvil) && this.AnvilAllowed)
                {
                    list.Add(new Move(column, MoveType.Anvil, DiscType.Anvil));
                }
            }
            if (!this.Grid.IsEmpty())
            {
                if (player.HasDisk(DiscType.Bomb) && this.BombAllowed)
                {
                    list.Add(new Move(column, MoveType.Bomb, DiscType.Bomb));
                }
            }
        }
        return list;
    }

    public void ExecuteMove(Guid playerId, IMove move)
    {
        IPlayer player = GetPlayerById(playerId);
        if (player == null)
        {
            throw new InvalidOperationException(message: "Player is null");
            return;
        }
        if (!player.HasDisk(move.DiscType))
        {
            throw new InvalidOperationException(message: "Player does not have any disks left");
            return;
        }
        if (this.Finished)
        {
            throw new InvalidOperationException(message: "Game already finished");
            return;
        }
        if (playerId != this.PlayerToPlayId)
        {
            throw new InvalidOperationException(message: "Not the player to play");
            return;
        }
        if (move.Type is MoveType.SlideIn)
        {
            player.RemoveDisc(move.DiscType);
            this.PlayerToPlayId = GetOpponent(playerId).Id;
            this.LastDisc = new Disc(move.DiscType, player.Color);
            this.Grid.SlideInDisc(new Disc(move.DiscType, player.Color), move.Column);
        }
        else if (move.Type is MoveType.PopOut)
        {
            player.RemoveDisc(move.DiscType);
            this.LastDisc = new Disc(move.DiscType, player.Color);
            IPlayer opponent = GetOpponent(playerId);
            if (this.Grid.Cells[this.Grid.NumberOfRows - 1, move.Column].Color == player.Color)
            {
                player.AddDisc(DiscType.Normal, 1);
            }
            else
            {
                opponent.AddDisc(DiscType.Normal, 1);
            }
            this.Grid.PopOutDisc(new Disc(move.DiscType, player.Color), move.Column);
            this.PlayerToPlayId = opponent.Id;
        }
        else if (move.Type is MoveType.Anvil)
        {
            player.RemoveDisc(move.DiscType);
            this.LastDisc = new Disc(move.DiscType, player.Color);
            this.Grid.AnvilDisc(new Disc(move.DiscType, player.Color), move.Column, this);
            IPlayer opponent = GetOpponent(playerId);
            this.PlayerToPlayId = opponent.Id;
        }
        else if (move.Type is MoveType.Bomb)
        {
            player.RemoveDisc(move.DiscType);
            this.LastDisc = new Disc(move.DiscType, player.Color);
            this.Grid.BombDisc(new Disc(move.DiscType, player.Color), this);
            IPlayer opponent = GetOpponent(playerId);
            this.PlayerToPlayId = opponent.Id;
        }
        else if (move.Type is MoveType.Wall)
        {
            player.RemoveDisc(move.DiscType);
            this.LastDisc = new Disc(move.DiscType, player.Color);
            this.Grid.WallDisc(new Disc(move.DiscType, player.Color), move.Column);
        }
        else
        {
            throw new NotImplementedException();
        }
    }

    public IPlayer GetPlayerById(Guid playerId)
    {
        if (this.Player1.Id == playerId)
        {
            return this.Player1;
        }
        else if (this.Player2.Id == playerId)
        {
            return this.Player2;
        }
        else
        {
            throw new InvalidOperationException(message: "Player not found");
        }
    }

    public IPlayer GetPlayerByColor(DiscColor color)
    {
        if (this.Player1.Color == color)
        {
            return this.Player1;
        }
        else if (this.Player2.Color == color)
        {
            return this.Player2;
        }
        else
        {
            throw new InvalidOperationException(message: "Player not found");
        }
    }

    public IPlayer GetOpponent(Guid playerId)
    {
        if (this.Player1.Id == playerId)
        {
            return this.Player2;
        }
        else if (this.Player2.Id == playerId)
        {
            return this.Player1;
        }
        else
        {
            throw new InvalidOperationException();
        }
    }
}