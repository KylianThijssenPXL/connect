﻿using ConnectFour.Domain.GameDomain.Contracts;
using ConnectFour.Domain.GridDomain;

namespace ConnectFour.Domain.GameDomain;

/// <inheritdoc cref="IMove"/>
public class Move : IMove
{
    public Move(int column, MoveType type = MoveType.SlideIn, DiscType discType = DiscType.Normal)
    {
        this.Column = column;
        this.Type = type;
        this.DiscType = discType;
    }

    public MoveType Type { get; } = MoveType.SlideIn;

    public DiscType DiscType { get; } = DiscType.Normal;

    public int Column { get; } = 7;
}