﻿using ConnectFour.Domain.GameDomain.Contracts;

namespace ConnectFour.Domain.GameDomain;

/// <inheritdoc cref="IGameCandidate"/>
internal class GameCandidate : IGameCandidate
{
    public User User { get; }
    public GameSettings GameSettings { get; }
    public Guid GameId { get; set; }
    public Guid ProposedOpponentUserId { get; set; }

    internal GameCandidate(User user, GameSettings gameSettings)
    {
        this.User = user;
        this.GameSettings = gameSettings;
    }

    public bool CanChallenge(IGameCandidate targetCandidate)
    {
        if (targetCandidate == null) return false;
        if (targetCandidate.GameId != Guid.Empty) return false;
        if (GameId != Guid.Empty) return false;
        if (targetCandidate.User.Id == User.Id) return false;
        if (targetCandidate.GameSettings.ConnectionSize != GameSettings.ConnectionSize) return false;
        if (targetCandidate.GameSettings.GridRows != GameSettings.GridRows) return false;
        if (targetCandidate.GameSettings.GridColumns != GameSettings.GridColumns) return false;
        if (targetCandidate.GameSettings.EnablePopOut != GameSettings.EnablePopOut) return false;
        if (targetCandidate.GameSettings.PopOutCount != GameSettings.PopOutCount) return false;
        if (targetCandidate.GameSettings.EnableAnvil != GameSettings.EnableAnvil) return false;
        if (targetCandidate.GameSettings.AnvilCount != GameSettings.AnvilCount) return false;
        if (targetCandidate.GameSettings.EnableBomb != GameSettings.EnableBomb) return false;
        if (targetCandidate.GameSettings.BombCount != GameSettings.BombCount) return false;
        if (targetCandidate.GameSettings.EnableWall != GameSettings.EnableWall) return false;
        if (targetCandidate.GameSettings.WallCount != GameSettings.WallCount) return false;
        return true;
    }

    public void Challenge(IGameCandidate targetCandidate)
    {
        if (CanChallenge(targetCandidate))
        {
            this.ProposedOpponentUserId = targetCandidate.User.Id;
        }
        else
        {
            throw new InvalidOperationException(message: "can not challenge target");
        }
    }

    public void AcceptChallenge(IGameCandidate challenger)
    {
        if (challenger.ProposedOpponentUserId != User.Id)
        {
            throw new InvalidOperationException("this was for another candidate");
        }
        if (GameId != Guid.Empty)
        {
            throw new InvalidOperationException("already in a game");
        }
        this.ProposedOpponentUserId = challenger.User.Id;
    }

    public void WithdrawChallenge()
    {
        throw new InvalidOperationException(message: "other candidate");
    }
}