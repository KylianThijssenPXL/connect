﻿namespace ConnectFour.Common;

public class DataNotFoundException : Exception
{
}