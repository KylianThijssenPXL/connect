﻿using ConnectFour.AppLogic.Contracts;
using ConnectFour.Domain;
using ConnectFour.Domain.GameDomain;
using ConnectFour.Domain.GameDomain.Contracts;
using ConnectFour.Domain.PlayerDomain;
using ConnectFour.Domain.PlayerDomain.Contracts;
using System.Runtime.Intrinsics.X86;

namespace ConnectFour.AppLogic;

/// <inheritdoc cref="IGameService"/>
internal class GameService : IGameService
{
    public IGameFactory GameFactory { get; }

    public IGameRepository GameRepository { get; }

    public GameService(IGameFactory gameFactory, IGameRepository gameRepository)
    {
        this.GameFactory = gameFactory;
        this.GameRepository = gameRepository;
    }

    public IGame CreateGameForUsers(User user1, User user2, GameSettings settings)
    {
        IGame game = this.GameFactory.CreateNewTwoPlayerGame(settings, user1, user2);
        this.GameRepository.Add(game);
        return game;
    }

    public IGame GetById(Guid gameId)
    {
        return this.GameRepository.GetById(gameId);
    }

    public void ExecuteMove(Guid gameId, Guid playerId, IMove move)
    {
        IGame game = GetById(gameId);
        game.ExecuteMove(playerId, move);
    }
    public void ExecuteComputerMove(Guid gameId, Guid playerId)
    {
        IGame game = GetById(gameId);
        IPlayer opponent = game.GetOpponent(playerId);
        if (opponent is ComputerPlayer computerPlayer)
        {
            IMove bestMove = computerPlayer.Strategy.GetBestMoveFor(computerPlayer.Id, game);
            game.ExecuteMove(computerPlayer.Id, bestMove);
            if (bestMove.Type == MoveType.Wall)
            {
                IMove bestSecondMove = computerPlayer.Strategy.GetBestMoveFor(computerPlayer.Id, game);
                game.ExecuteMove(computerPlayer.Id, bestSecondMove);
            }
        }
    }

    public IGame CreateSinglePlayerGameForUser(User user, GameSettings settings)
    {
        IGame game = this.GameFactory.CreateNewSinglePlayerGame(settings, user);
        this.GameRepository.Add(game);
        return game;
    }
}
