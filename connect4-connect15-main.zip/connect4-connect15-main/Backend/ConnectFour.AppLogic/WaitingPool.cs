﻿using ConnectFour.AppLogic.Contracts;
using ConnectFour.Domain;
using ConnectFour.Domain.GameDomain;
using ConnectFour.Domain.GameDomain.Contracts;
using System.Diagnostics;
using System.Net.Http.Headers;

namespace ConnectFour.AppLogic;

/// <inheritdoc cref="IWaitingPool"/>
internal class WaitingPool : IWaitingPool
{
    public IGameCandidateFactory GameCandidateFactory { get; }
    public IGameCandidateMatcher GameCandidateMatcher { get; }
    public IGameCandidateRepository GameCandidateRepository { get; }
    public IGameService GameService { get; }
    public WaitingPool(
        IGameCandidateFactory gameCandidateFactory,
        IGameCandidateRepository gameCandidateRepository, 
        IGameCandidateMatcher gameCandidateMatcher, 
        IGameService gameService)
    {
        this.GameCandidateFactory = gameCandidateFactory;
        this.GameCandidateRepository = gameCandidateRepository;
        this.GameCandidateMatcher = gameCandidateMatcher;
        this.GameService = gameService;
    }

    public void Join(User user, GameSettings gameSettings)
    {
        IGameCandidate candidate = this.GameCandidateFactory.CreateNewForUser(user, gameSettings);
        this.GameCandidateRepository.AddOrReplace(candidate);
        if (candidate != null)
        {
            if (gameSettings.AutoMatchCandidates)
            {
            IList<IGameCandidate> list = this.FindCandidatesThatCanBeChallengedBy(user.Id);
                if (list != null)
                {
                    IGameCandidate target = this.GameCandidateMatcher.SelectOpponentToChallenge(list);
                    if (target != null)
                    {
                        candidate.Challenge(target);
                        target.AcceptChallenge(candidate);
                        IGame game = this.GameService.CreateGameForUsers(candidate.User, target.User, gameSettings);
                        candidate.GameId = game.Id;
                        target.GameId = game.Id;
                    }
                }
            }
        }
    }

    public void Leave(Guid userId)
    {
        this.GameCandidateRepository.RemoveCandidate(userId);
    }

    public IGameCandidate GetCandidate(Guid userId)
    {
        return this.GameCandidateRepository.GetCandidate(userId);
    }

    public void Challenge(Guid challengerUserId, Guid targetUserId)
    {
        throw new NotImplementedException();
    }

    public IList<IGameCandidate> FindCandidatesThatCanBeChallengedBy(Guid userId)
    {
        return this.GameCandidateRepository.FindCandidatesThatCanBeChallengedBy(userId);
    }

    public void WithdrawChallenge(Guid userId)
    {
        IGameCandidate candidate = GetCandidate(userId);
        candidate.WithdrawChallenge();
    }

    public IList<IGameCandidate> FindChallengesFor(Guid challengedUserId)
    {
        return this.GameCandidateRepository.FindChallengesFor(challengedUserId);
    }
}