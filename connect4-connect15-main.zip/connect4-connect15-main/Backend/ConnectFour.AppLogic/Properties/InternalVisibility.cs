﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ConnectFour.Api")]
[assembly: InternalsVisibleTo("ConnectFour.AppLogic.Tests")]