global using NUnit.Framework;
global using ConnectFour.Api.Controllers;
global using Moq;
global using Guts.Client.Core;