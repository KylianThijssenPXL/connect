﻿namespace ConnectFour.Api.Models;

public class PingResultModel
{
    public bool IsAlive { get; set; }
    public string Greeting { get; set; }
}