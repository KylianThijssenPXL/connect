﻿namespace ConnectFour.Api.Models;

public class AccessPassModel
{
    public UserModel User { get; set; }
    public string Token { get; set; }
}